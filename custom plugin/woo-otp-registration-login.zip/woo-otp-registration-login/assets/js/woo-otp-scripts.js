jQuery(document).ready(function($) {
    if (typeof woo_ajax === 'undefined' || woo_ajax.otp_enabled !== 'yes') {
        $('.otp-form, #phone-login-form').hide();
        console.log('OTP disabled or woo_ajax not defined');
        return;
    }

    console.log('Woo OTP Scripts Loaded'); // Debug: Script loaded

    function startCountdown(button, messageElement, duration = 60) {
        let timeLeft = duration;
        button.prop('disabled', true).text(`Resend OTP (${timeLeft}s)`);
        
        let timer = setInterval(function() {
            timeLeft--;
            button.text(`Resend OTP (${timeLeft}s)`);
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                button.text('Get OTP').prop('disabled', false);
                messageElement.hide();
            }
        }, 1000);
    }

    // Registration Form
    let regPhoneInput = $('#reg_billing_phone');
    let sendRegOtpBtn = $('#sendRegOtp');
    let regOtpSection = $('#reg-otp-section');
    let regOtpInput = $('#reg_otp_code');
    let verifyRegOtpBtn = $('#verifyRegOtpBtn');
    let regOtpMessage = $('#reg-otp-message');
    let regPhoneError = $('#reg-phone-error');

    regPhoneInput.on("input", function() {
        $(this).val($(this).val().replace(/\D/g, '').substring(0, 10));
    });

    sendRegOtpBtn.on("click", function() {
        let phone = regPhoneInput.val();
        if (phone.length !== 10) {
            regPhoneError.text("Enter a valid 10-digit phone number.").show();
            return;
        }
        regPhoneError.hide();
        sendRegOtpBtn.text("Sending...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'send_otp', 
            phone: phone, 
            nonce: woo_ajax.nonce,
            context: 'register'
        }, function(response) {
            if (response.success) {
                regOtpMessage.text("OTP sent successfully!").css("color", "green").show();
                regOtpSection.show();
                startCountdown(sendRegOtpBtn, regOtpMessage);
                if (woo_ajax.test_mode === 'yes' && response.data.otp) {
                    console.log('Test Mode Registration OTP:', response.data.otp);
                }
            } else {
                sendRegOtpBtn.text("Get OTP").prop("disabled", false);
                regOtpMessage.text(response.data.message || "Failed to send OTP.").css("color", "red").show();
            }
        });
    });

    verifyRegOtpBtn.on("click", function() {
        let phone = regPhoneInput.val();
        let otp = regOtpInput.val();
        if (!otp || otp.length !== 6) {
            regOtpMessage.text("Enter a valid 6-digit OTP.").css("color", "red").show();
            return;
        }
        verifyRegOtpBtn.text("Verifying...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'verify_otp', 
            phone: phone, 
            otp: otp, 
            nonce: woo_ajax.nonce,
            context: 'register'
        }, function(response) {
            verifyRegOtpBtn.text("Verify & Register").prop("disabled", false);
            if (response.success) {
                regOtpMessage.text("OTP verified! Registering...").css("color", "green").show();
                $('#phone-register-form').append('<input type="hidden" name="otp_verified" value="1">');
                $('#phone-register-form').submit();
            } else {
                regOtpMessage.text(response.data.message || "Invalid OTP.").css("color", "red").show();
            }
        });
    });

    // Login Form
    let loginInput = $('#login_username');
    let passwordSection = $('#password-section');
    let sendOtpSection = $('#send-otp-section');
    let loginOtpSection = '#login-otp-section';
    let submitSection = $('#submit-section');
    let sendLoginOtpBtn = $('#sendLoginOtp');
    let verifyLoginOtpBtn = '#verifyLoginOtpBtn';
    let loginOtpInput = $('#login_otp_code');
    let loginOtpMessage = $('#login-otp-message');
    let loginInputError = $('#login-input-error');

    function toggleFields() {
        let inputVal = loginInput.val().trim();
        let isPhone = /^\d{10}$/.test(inputVal.replace(/\D/g, ''));
        let isEmail = inputVal.includes('@') && inputVal.includes('.');

        if (isPhone) {
            passwordSection.hide();
            submitSection.hide();
            sendOtpSection.show();
            $(loginOtpSection).hide();
            loginOtpMessage.hide();
            loginInputError.hide();
        } else if (isEmail) {
            passwordSection.show();
            submitSection.show();
            sendOtpSection.hide();
            $(loginOtpSection).hide();
            loginOtpMessage.hide();
            loginInputError.hide();
        } else {
            passwordSection.hide();
            submitSection.hide();
            sendOtpSection.hide();
            $(loginOtpSection).hide();
            loginOtpMessage.hide();
        }
    }

    loginInput.on('input', function() {
        toggleFields();
    });

    sendLoginOtpBtn.on("click", function() {
        let phone = loginInput.val().replace(/\D/g, '');
        if (phone.length !== 10) {
            loginInputError.text("Enter a valid 10-digit phone number.").show();
            return;
        }
        loginInputError.hide();
        sendLoginOtpBtn.text("Sending...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'send_otp', 
            phone: phone, 
            nonce: woo_ajax.nonce,
            context: 'login'
        }, function(response) {
            if (response.success) {
                loginOtpMessage.text("OTP sent successfully!").css("color", "green").show();
                $(loginOtpSection).show();
                startCountdown(sendLoginOtpBtn, loginOtpMessage);
                if (woo_ajax.test_mode === 'yes' && response.data.otp) {
                    console.log('Test Mode Login OTP:', response.data.otp);
                }
            } else {
                sendLoginOtpBtn.text("Get OTP").prop("disabled", false);
                loginOtpMessage.text(response.data.message || "Failed to send OTP.").css("color", "red").show();
            }
        });
    });

    $(verifyLoginOtpBtn).on("click", function() {
        let phone = loginInput.val().replace(/\D/g, '');
        let otp = loginOtpInput.val();
        if (!otp || otp.length !== 6) {
            loginOtpMessage.text("Enter a valid 6-digit OTP.").css("color", "red").show();
            return;
        }
        $(verifyLoginOtpBtn).text("Verifying...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'verify_otp', 
            phone: phone, 
            otp: otp, 
            nonce: woo_ajax.nonce,
            context: 'login'
        }, function(response) {
            $(verifyLoginOtpBtn).text("Verify & Login").prop("disabled", false);
            if (response.success) {
                loginOtpMessage.text("OTP verified! Logging in...").css("color", "green").show();
                $('#phone-login-form').append('<input type="hidden" name="otp_verified_login" value="1">');
                $('#phone-login-form').submit();
            } else {
                loginOtpMessage.text(response.data.message || "Invalid OTP.").css("color", "red").show();
            }
        });
    });

    // Show/Hide Password Toggle
    if ($('.show-password-input').length) {
        $(document).on('click', '.show-password-input', function(e) {
            e.preventDefault();
            let passwordInput = $('#otp_password');
            console.log('Password input found:', passwordInput.length);
        
            if (passwordInput.length) {
                if (passwordInput.attr('type') === 'password') {
                    passwordInput.attr('type', 'text');
                    $(this).attr('aria-label', 'Hide password');
                    $(this).addClass('hide-password');
                } else {
                    passwordInput.attr('type', 'password');
                    $(this).attr('aria-label', 'Show password');
                    $(this).removeClass('hide-password');
                }
            } 
        });
    } 
});