<?php if (!defined('ABSPATH')) exit; ?>
<div class="wd-dropdown wd-dropdown-register">
    <div class="login-dropdown-inner woocommerce">
        <span class="wd-heading">
            <span class="title"><?php _e('Sign in', 'woo-otp'); ?></span>
            <a class="create-account-link" href="<?php echo esc_url(site_url('/my-account/?action=register')); ?>"><?php _e('Create an Account', 'woo-otp'); ?></a>
        </span>
        <form method="post" class="login woocommerce-form woocommerce-form-login" id="phone-login-form">
            <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide form-row-username">
                <label for="login_username"><?php _e('Phone number or Email address', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="login_username" value="" required />
                <p id="login-input-error" style="color: red; display: none;"></p>
            </p>
            <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide form-row-password" id="password-section" style="display: none;">
                <label for="otp_password"><?php _e('Password', 'woo-otp'); ?> <span class="required">*</span></label>
                <span class="password-input">
                    <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="otp_password" autocomplete="current-password" required />
                    <button class="show-password-input" aria-label="Show password" aria-describedby="otp_password"></button>
                </span>
            </p>
            <p class="form-row" id="send-otp-section" style="display: none;">
                <button type="button" id="sendLoginOtp" class="button woocommerce-button"><?php _e('Get OTP', 'woo-otp'); ?></button>
            </p>
            <div id="login-otp-section" style="display:none;">
                <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide form-row-otp">
                    <label for="login_otp_code"><?php _e('Enter OTP', 'woo-otp'); ?> <span class="required">*</span></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="otp_code" id="login_otp_code" maxlength="6" />
                </p>
                <p class="form-row">
                    <button type="button" id="verifyLoginOtpBtn" class="button woocommerce-button"><?php _e('Verify & Login', 'woo-otp'); ?></button>
                </p>
            </div>
            <p class="form-row" id="submit-section" style="display: none;">
                <input type="hidden" id="otp_woocommerce-login-nonce" name="woocommerce-login-nonce" value="<?php echo wp_create_nonce('woocommerce-login'); ?>">
                <input type="hidden" name="_wp_http_referer" value="<?php echo esc_url(home_url('/')); ?>">
                <button type="submit" class="button woocommerce-button woocommerce-form-login__submit" name="login" value="Log in"><?php _e('Log in', 'woo-otp'); ?></button>
            </p>
            <p class="login-form-footer">
                <a href="<?php echo esc_url(site_url('/my-account/lost-password/')); ?>" class="woocommerce-LostPassword lost_password"><?php _e('Lost your password?', 'woo-otp'); ?></a>
                <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
                    <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" value="forever"><?php _e('Remember me', 'woo-otp'); ?>
                </label>
            </p>
            <p id="login-otp-message" style="color: red; display: none;"></p>
        </form>
    </div>
</div>