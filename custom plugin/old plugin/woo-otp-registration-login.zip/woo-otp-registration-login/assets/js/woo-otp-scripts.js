jQuery(document).ready(function($) {
    if (woo_ajax.otp_enabled !== 'yes') {
        $('.otp-form, #phone-login-form').hide();
        return;
    }

    function startCountdown(button, messageElement, duration = 60) {
        let timeLeft = duration;
        button.prop('disabled', true).text(`Resend OTP (${timeLeft}s)`);
        
        let timer = setInterval(function() {
            timeLeft--;
            button.text(`Resend OTP (${timeLeft}s)`);
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                button.text('Get OTP').prop('disabled', false);
                messageElement.hide();
            }
        }, 1000);
    }

    // Login Form Event Delegation
    $(document).on('input', '#login_username', function() {
        toggleFields($(this));
    });

    $(document).on('click', '#sendLoginOtp', function() {
        let $this = $(this);
        let inputVal = $('#login_username').val();
        let phone = getTenDigitPhoneNumber(inputVal);  // Changed here
        let $loginOtpMessage = $('#login-otp-message');
        let $loginInputError = $('#login-input-error');

        if (!phone) {  // Check if phone is null (invalid)
            $loginInputError.text("Enter a valid 10-digit phone number.").show();
            return;
        }
        $loginInputError.hide();
        $this.text("Sending...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'send_otp', 
            phone: phone, 
            nonce: woo_ajax.nonce,
            context: 'login'
        }, function(response) {
            if (response.success) {
                $loginOtpMessage.text("OTP sent successfully!").css("color", "green").show();
                $('#login-otp-section').show();
                startCountdown($this, $loginOtpMessage);
                if (woo_ajax.test_mode === 'yes' && response.data.otp) {
                    console.log('Test Mode Login OTP:', response.data.otp);
                }
            } else {
                $this.text("Get OTP").prop("disabled", false);
                $loginOtpMessage.text(response.data.message || "Failed to send OTP.").css("color", "red").show();
            }
        });
    });

    $(document).on('click', '#verifyLoginOtpBtn', function() {
        let $this = $(this);
        let inputVal = $('#login_username').val();
        let phone = getTenDigitPhoneNumber(inputVal);  // Changed here
        let otp = $('#login_otp_code').val();
        let $loginOtpMessage = $('#login-otp-message');

        if (!otp || otp.length !== 6) {
            $loginOtpMessage.text("Enter a valid 6-digit OTP.").css("color", "red").show();
            return;
        }
        $this.text("Verifying...").prop("disabled", true);

        $.post(woo_ajax.ajax_url, { 
            action: 'verify_otp', 
            phone: phone, 
            otp: otp, 
            nonce: woo_ajax.nonce,
            context: 'login'
        }, function(response) {
            $this.text("Verify & Login").prop("disabled", false);
            if (response.success) {
                $loginOtpMessage.text("OTP verified! Logging in...").css("color", "green").show();
                $('#phone-login-form').append('<input type="hidden" name="otp_verified_login" value="1">');
                $('#phone-login-form').submit();
            } else {
                $loginOtpMessage.text(response.data.message || "Invalid OTP.").css("color", "red").show();
            }
        });
    });

    function getTenDigitPhoneNumber(inputVal) {
        // Remove all non-digit characters
        let digits = inputVal.replace(/\D/g, '');
        
        // Handle common cases: +91 or 0 prefix
        if (digits.startsWith('91') && digits.length === 12) {
            // Remove +91 (country code) and take the last 10 digits
            digits = digits.substring(2);
        } else if (digits.startsWith('0') && digits.length === 11) {
            // Remove leading 0 and take the last 10 digits
            digits = digits.substring(1);
        }
        
        // Return the 10-digit number if valid, otherwise null
        return digits.length === 10 ? digits : null;
    }

    function getPhoneNumber(inputVal) {
        // Remove all non-digit characters
        let digits = inputVal.replace(/\D/g, '');
        
        // Handle common cases: +91 or 0 prefix
        if (digits.startsWith('91') && digits.length === 12) {
            // Remove +91 (country code) and take the last 10 digits
            digits = digits.substring(2);
        } else if (digits.startsWith('0') && digits.length === 11) {
            // Remove leading 0 and take the last 10 digits
            digits = digits.substring(1);
        }
        
        // Return the 10-digit number if valid, otherwise null
        //return digits.length === 10 ? digits : null;
        return digits;
        console.log(digits);
    }


    function toggleFields($input) {
        let inputVal = $input.val().trim();
        let isPhone = getPhoneNumber(inputVal);  // Already using this
        let isEmail = inputVal.includes('@') && inputVal.includes('.');
        let $form = $input.closest('#phone-login-form');

        if (isPhone) {
            $form.find('#password-section').hide();
            $form.find('#submit-section').hide();
            $form.find('#send-otp-section').show();
            $form.find('#login-otp-section').hide();
            $form.find('#login-otp-message').hide();
            $form.find('#login-input-error').hide();
        } else if (isEmail) {
            $form.find('#password-section').show();
            $form.find('#submit-section').show();
            $form.find('#send-otp-section').hide();
            $form.find('#login-otp-section').hide();
            $form.find('#login-otp-message').hide();
            $form.find('#login-input-error').hide();
        } else {
            $form.find('#password-section').hide();
            $form.find('#submit-section').hide();
            $form.find('#send-otp-section').hide();
            $form.find('#login-otp-section').hide();
            $form.find('#login-otp-message').hide();
        }
    }

    // Show/Hide Password Toggle
    $(document).on('click', '.show-password-input', function(e) {
        e.preventDefault();
        let $passwordInput = $(this).siblings('#otp_password');
        if ($passwordInput.length) {
            if ($passwordInput.attr('type') === 'password') {
                $passwordInput.attr('type', 'text');
                $(this).attr('aria-label', 'Hide password').addClass('hide-password');
            } else {
                $passwordInput.attr('type', 'password');
                $(this).attr('aria-label', 'Show password').removeClass('hide-password');
            }
        }
    });

    // Dropdown Active State Management
    let isFormActive = false;

    $(document).on('focus', '.whb-header #phone-login-form input, .whb-sticky-header #phone-login-form input', function() {
        isFormActive = true;
        const $header = $(this).closest('.whb-header, .whb-sticky-header');
        const $dropdown = $header.find('.wd-dropdown-register');
        $dropdown.addClass('wd-active-login');
    });

    $(document).on('blur', '.whb-header #phone-login-form input, .whb-sticky-header #phone-login-form input', function() {
        setTimeout(function() {
            if (!$('.whb-header #phone-login-form input:focus, .whb-sticky-header #phone-login-form input:focus').length) {
                isFormActive = false;
            }
        }, 200);
    });

    setInterval(function() {
        const $header = $('.whb-header, .whb-sticky-header');
        const $dropdown = $header.find('.wd-dropdown-register');
        const $hoverTrigger = $header.find('.wd-event-hover');
        const isHovering = $hoverTrigger.length && $hoverTrigger[0].matches(':hover');

        if ((isHovering || isFormActive) && !$dropdown.hasClass('wd-active-login')) {
            $dropdown.addClass('wd-active-login');
        } else if (!isHovering && !isFormActive && $dropdown.hasClass('wd-active-login')) {
            $dropdown.removeClass('wd-active-login');
        }
    }, 100);
});