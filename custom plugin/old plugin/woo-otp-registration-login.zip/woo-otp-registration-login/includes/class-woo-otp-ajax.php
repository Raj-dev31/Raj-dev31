<?php

if (!defined('ABSPATH')) {

    exit;

}



class Woo_OTP_Ajax {

    private static $instance = null;



    public static function get_instance() {

        if (self::$instance === null) {

            self::$instance = new self();

        }

        return self::$instance;

    }



    private function __construct() {

        add_action('wp_ajax_send_otp', [$this, 'send_otp']);

        add_action('wp_ajax_nopriv_send_otp', [$this, 'send_otp']);

        add_action('wp_ajax_verify_otp', [$this, 'verify_otp']);

        add_action('wp_ajax_nopriv_verify_otp', [$this, 'verify_otp']);

    }



    public function send_otp() {

        if (!isset($_POST['phone']) || !isset($_POST['context'])) {

            wp_send_json_error(['message' => 'Phone number or context missing']);

            return;

        }



        if (get_option('woo_otp_enable', 'yes') !== 'yes') {

            wp_send_json_error(['message' => 'OTP verification is disabled']);

            return;

        }



        $phone = sanitize_text_field($_POST['phone']);

        $context = sanitize_text_field($_POST['context']);

        

        $last_sent = get_option("otp_last_sent_$phone");

        if ($last_sent && (time() - $last_sent < 60)) {

            wp_send_json_error(['message' => 'Please wait 60 seconds before requesting a new OTP.']);

            return;

        }



        $otp = rand(100000, 999999);

        update_option("otp_$phone", $otp, false);

        update_option("otp_last_sent_$phone", time(), false);



        $test_mode = get_option('woo_otp_test_mode', 'no');

        if ($test_mode === 'yes') {

            wp_send_json_success([

                'message' => 'OTP generated (Test Mode)',

                'otp' => $otp

            ]);

            return;

        }



        $username = get_option('woo_otp_sms_username', '');

        $password = get_option('woo_otp_sms_password', '');

        $api_url = get_option('woo_otp_sms_api_url', 'https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30');

        $sender_id = get_option('woo_otp_sms_sender_id', 'AruToys');



        if (empty($username) || empty($password)) {

            wp_send_json_error(['message' => 'SMS API credentials not configured']);

            return;

        }



        $auth_header = 'Authorization: Basic ' . base64_encode("$username:$password");

        $sms_text = ($context === 'login') 

            ? get_option('woo_otp_login_sms', 'Welcome to Arutoys! Your Login OTP is {otp}.')

            : get_option('woo_otp_register_sms', 'Welcome to Arutoys! Your OTP is {otp}.');

        $message_body = str_replace('{otp}', $otp, $sms_text);



        $message_data = json_encode([

            "from" => $sender_id,

            "to"   => "+91$phone",

            "routingGroup" => "ECONOMY",

            "encoding" => "TEXT",

            "body" => $message_body

        ]);



        $ch = curl_init($api_url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_HTTPHEADER, [

            'Content-Type: application/json',

            $auth_header

        ]);

        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);



        $response = curl_exec($ch);

        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);



        if ($http_status !== 201) {

            wp_send_json_error(['message' => 'Error sending OTP']);

        } else {

            wp_send_json_success(['message' => 'OTP sent successfully']);

        }

    }



    public function verify_otp() {

        if (!isset($_POST['phone']) || !isset($_POST['otp']) || !isset($_POST['context'])) {

            wp_send_json_error(['message' => 'Missing parameters']);

            return;

        }

        

        $phone = sanitize_text_field($_POST['phone']);

        $otp_entered = sanitize_text_field($_POST['otp']);

        $context = sanitize_text_field($_POST['context']);

        $stored_otp = get_option("otp_$phone");



        if ($otp_entered != $stored_otp) {

            wp_send_json_error(['message' => 'Invalid OTP']);

        } else {

            delete_option("otp_$phone");

            if ($context === 'login') {

                $user = get_users([

                    'meta_key' => 'billing_phone',

                    'meta_value' => $phone,

                    'number' => 1

                ]);

                if (empty($user)) {

                    wp_send_json_error(['message' => 'No user found with this phone number']);

                    return;

                }

            }

            wp_send_json_success(['message' => 'OTP verified']);

        }

    }

}