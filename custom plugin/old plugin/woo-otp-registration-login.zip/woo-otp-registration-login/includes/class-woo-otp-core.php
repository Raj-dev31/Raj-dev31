<?php
if (!defined('ABSPATH')) {
    exit;
}

class Woo_OTP_Core {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->register_hooks();
    }

    private function register_hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_shortcode('otp_registration_form', [$this, 'registration_form']);
        add_shortcode('otp_login_form', [$this, 'login_form']);
        add_action('init', [$this, 'register_after_otp']);
        add_action('init', [$this, 'login_after_otp']);
        add_action('woocommerce_register_post', [$this, 'validate_phone_field'], 10, 3);
        add_action('woocommerce_created_customer', [$this, 'save_phone_field']);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('woo-otp-styles', WOO_OTP_URL . 'assets/css/woo-otp-styles.css', array('dashicons'), WOO_OTP_VERSION);
        wp_enqueue_script('woo-otp-scripts', WOO_OTP_URL . 'assets/js/woo-otp-scripts.js', array('jquery'), WOO_OTP_VERSION, true);
        wp_localize_script('woo-otp-scripts', 'woo_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woo_nonce'),
            'test_mode' => get_option('woo_otp_test_mode', 'no'),
            'otp_enabled' => get_option('woo_otp_enable', 'yes')
        ));
    }

    public function registration_form() {
        if (is_user_logged_in()) {
            return '<p>' . __('You are already logged in.', 'woo-otp') . '</p>';
        }

        ob_start();
        include WOO_OTP_PATH . 'templates/registration-form.php';
        return ob_get_clean();
    }

    public function login_form() {
        if (is_user_logged_in()) {
            return '<p>' . __('You are already logged in.', 'woo-otp') . '</p>';
        }

        ob_start();
        include WOO_OTP_PATH . 'templates/login-form.php';
        return ob_get_clean();
    }

    public function register_after_otp() {
        if (isset($_POST['otp_verified']) && $_POST['otp_verified'] == '1') {
            $phone = sanitize_text_field($_POST['billing_phone']);
            
            $existing_user = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);

            if (!empty($existing_user)) {
                wc_add_notice(__('This phone number is already registered. Please log in.', 'woo-otp'), 'error');
                return;
            }

            $userdata = [
                'user_login' => $phone,
                'user_pass'  => wp_generate_password(),
                'role'       => 'customer'
            ];

            $user_id = wp_insert_user($userdata);
            update_user_meta($user_id, 'billing_phone', $phone);
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);

            wp_safe_redirect(site_url('/my-account/'));
            exit();
        }
    }

    public function login_after_otp() {
        if (isset($_POST['otp_verified_login']) && $_POST['otp_verified_login'] == '1') {
            $phone = sanitize_text_field($_POST['username']);
            
            $user = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);

            if (empty($user)) {
                wc_add_notice(__('No account found with this phone number.', 'woo-otp'), 'error');
                return;
            }

            $user_id = reset($user)->ID;
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);

            wp_safe_redirect(wc_get_page_permalink('myaccount'));
            exit();
        } elseif (isset($_POST['login']) && isset($_POST['username']) && isset($_POST['password'])) {
            // Handle email login with password
            $email = sanitize_email($_POST['username']);
            $password = $_POST['password']; // WordPress handles sanitization internally
            $nonce = sanitize_text_field($_POST['woocommerce-login-nonce']);

            if (!wp_verify_nonce($nonce, 'woocommerce-login')) {
                wc_add_notice(__('Security check failed. Please try again.', 'woo-otp'), 'error');
                return;
            }

            if (!is_email($email)) {
                wc_add_notice(__('Please enter a valid email address for password login.', 'woo-otp'), 'error');
                return;
            }

            $user = wp_authenticate_email_password(null, $email, $password);

            if (is_wp_error($user)) {
                wc_add_notice($user->get_error_message(), 'error');
                return;
            }

            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID);

            wp_safe_redirect(wc_get_page_permalink('myaccount'));
            exit();
        }
    }

    public function validate_phone_field($username, $email, $validation_errors) {
        if (empty($_POST['billing_phone'])) {
            $validation_errors->add('billing_phone_error', __('Please provide a valid phone number.', 'woo-otp'));
        }
        return $validation_errors;
    }

    public function save_phone_field($customer_id) {
        if (isset($_POST['billing_phone'])) {
            update_user_meta($customer_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']));
        }
    }
}