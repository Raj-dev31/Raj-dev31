<?php
if (!defined('ABSPATH')) {
    exit;
}

class IAM_Ajax {
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_iam_save_alt_text', array($this, 'save_alt_text'));
        add_action('wp_ajax_iam_bulk_update_alt_text', array($this, 'bulk_update_alt_text'));
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_image-alt-manager') {
            return;
        }
        wp_enqueue_style('iam-admin-style', IAM_PLUGIN_URL . 'assets/css/admin-style.css', array(), '1.6.0');
        wp_enqueue_script('iam-admin-script', IAM_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), '1.6.0', true);
        wp_localize_script('iam-admin-script', 'iam_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'save_nonce' => wp_create_nonce('iam_save_alt_text'),
            'load_more_nonce' => wp_create_nonce('iam_load_more'),
        ));
    }

    public function save_alt_text() {
        check_ajax_referer('iam_save_alt_text', 'nonce');
        $image_id = intval($_POST['image_id']);
        $alt_text = sanitize_text_field($_POST['alt_text']);

        if (empty($alt_text)) {
            $image = get_post($image_id);
            $alt_text = sanitize_text_field($image->post_title);
        }

        update_post_meta($image_id, '_wp_attachment_image_alt', $alt_text);
        wp_send_json_success(__('Alt text updated.', 'image-alt-manager'));
    }

    public function bulk_update_alt_text() {
        check_ajax_referer('iam_save_alt_text', 'nonce');
        $images = get_posts(array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
        ));

        foreach ($images as $image) {
            $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
            if (empty($alt_text)) {
                update_post_meta($image->ID, '_wp_attachment_image_alt', sanitize_text_field($image->post_title));
            }
        }

        wp_send_json_success(__('Bulk update completed for missing alt text.', 'image-alt-manager'));
    }
}