<?php
if (!defined('ABSPATH')) {
    exit;
}

class IAM_Image_Manager {
    public function __construct() {}

    public static function display_image_manager() {
        $per_page = 10; // Initial number of images
        $paged = 1; // Start at page 1

        $args = array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'post_status' => 'inherit',
        );
        $query = new WP_Query($args);
        $images = $query->posts;
        $total_images = $query->found_posts;
        $max_pages = $query->max_num_pages;

        ?>
        <div class="iam-bulk-action">
            <button id="iam-bulk-update" class="iam-button iam-button-primary"><?php _e('Bulk Update Missing Alt Text', 'image-alt-manager'); ?></button>
        </div>
        <div class="iam-image-grid" data-total-pages="<?php echo esc_attr($max_pages); ?>" data-current-page="1">
            <?php
            if ($images) {
                foreach ($images as $image) {
                    $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                    $image_url = wp_get_attachment_url($image->ID);
                    ?>
                    <div class="iam-image-card">
                        <div class="iam-image-preview">
                            <?php echo wp_get_attachment_image($image->ID, 'thumbnail'); ?>
                        </div>
                        <div class="iam-image-details">
                            <p><strong><?php _e('Name:', 'image-alt-manager'); ?></strong> <?php echo esc_html($image->post_title); ?></p>
                            <p><strong><?php _e('URL:', 'image-alt-manager'); ?></strong> <a href="<?php echo esc_url($image_url); ?>" target="_blank"><?php echo esc_url($image_url); ?></a></p>
                            <div class="iam-alt-text">
                                <input type="text" name="alt_text[<?php echo $image->ID; ?>]" value="<?php echo esc_attr($alt_text); ?>" placeholder="<?php echo esc_attr($image->post_title); ?>" class="iam-input" />
                                <?php if (empty($alt_text)) : ?>
                                    <span class="iam-missing"><?php _e('Missing', 'image-alt-manager'); ?></span>
                                <?php endif; ?>
                            </div>
                            <button class="iam-button iam-save-alt" data-image-id="<?php echo $image->ID; ?>"><?php _e('Save', 'image-alt-manager'); ?></button>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p class="iam-no-images">' . __('No images found in your media library. Please upload some images to manage their alt text.', 'image-alt-manager') . '</p>';
            }
            ?>
        </div>
        <?php if ($max_pages > 1) : ?>
            <div class="iam-load-more">
                <button id="iam-load-more" class="iam-button"><?php _e('Load More', 'image-alt-manager'); ?></button>
            </div>
        <?php endif; ?>
        <?php
    }

    // AJAX handler for loading more images
    public static function load_more_images() {
        check_ajax_referer('iam_load_more', 'nonce');
        $paged = intval($_POST['page']);
        $per_page = 10;

        $args = array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'post_status' => 'inherit',
        );
        $query = new WP_Query($args);
        $images = $query->posts;

        ob_start();
        foreach ($images as $image) {
            $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
            $image_url = wp_get_attachment_url($image->ID);
            ?>
            <div class="iam-image-card">
                <div class="iam-image-preview">
                    <?php echo wp_get_attachment_image($image->ID, 'thumbnail'); ?>
                </div>
                <div class="iam-image-details">
                    <p><strong><?php _e('Name:', 'image-alt-manager'); ?></strong> <?php echo esc_html($image->post_title); ?></p>
                    <p><strong><?php _e('URL:', 'image-alt-manager'); ?></strong> <a href="<?php echo esc_url($image_url); ?>" target="_blank"><?php echo esc_url($image_url); ?></a></p>
                    <div class="iam-alt-text">
                        <input type="text" name="alt_text[<?php echo $image->ID; ?>]" value="<?php echo esc_attr($alt_text); ?>" placeholder="<?php echo esc_attr($image->post_title); ?>" class="iam-input" />
                        <?php if (empty($alt_text)) : ?>
                            <span class="iam-missing"><?php _e('Missing', 'image-alt-manager'); ?></span>
                        <?php endif; ?>
                    </div>
                    <button class="iam-button iam-save-alt" data-image-id="<?php echo $image->ID; ?>"><?php _e('Save', 'image-alt-manager'); ?></button>
                </div>
            </div>
            <?php
        }
        $html = ob_get_clean();
        wp_send_json_success($html);
    }
}
add_action('wp_ajax_iam_load_more', array('IAM_Image_Manager', 'load_more_images'));