jQuery(document).ready(function($) {
    // Save alt text
    $(document).on('click', '.iam-save-alt', function(e) {
        e.preventDefault();
        var $button = $(this);
        var imageId = $button.data('image-id');
        var altText = $('input[name="alt_text[' + imageId + ']"]').val();

        $.ajax({
            url: iam_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'iam_save_alt_text',
                image_id: imageId,
                alt_text: altText,
                nonce: iam_ajax.save_nonce
            },
            success: function(response) {
                alert(response.data);
            },
            error: function() {
                alert('Error saving alt text.');
            }
        });
    });

    // Bulk update
    $('#iam-bulk-update').on('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to update all missing alt texts with image names?')) {
            $.ajax({
                url: iam_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'iam_bulk_update_alt_text',
                    nonce: iam_ajax.save_nonce
                },
                success: function(response) {
                    alert(response.data);
                    location.reload();
                },
                error: function() {
                    alert('Error during bulk update.');
                }
            });
        }
    });

    // Load more
    $('#iam-load-more').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var $grid = $('.iam-image-grid');
        var currentPage = parseInt($grid.data('current-page'));
        var totalPages = parseInt($grid.data('total-pages'));
        var nextPage = currentPage + 1;

        $button.prop('disabled', true).text('Loading...');

        $.ajax({
            url: iam_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'iam_load_more',
                page: nextPage,
                nonce: iam_ajax.load_more_nonce
            },
            success: function(response) {
                if (response.success) {
                    $grid.append(response.data);
                    $grid.data('current-page', nextPage);
                    $button.prop('disabled', false).text('Load More');
                    if (nextPage >= totalPages) {
                        $button.hide();
                    }
                }
            },
            error: function() {
                alert('Error loading more images.');
                $button.prop('disabled', false).text('Load More');
            }
        });
    });
});