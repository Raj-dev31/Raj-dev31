=== WooCommerce OTP Registration & Login ===
Contributors: [Your Name]
Tags: woocommerce, otp, registration, login, sms, verification
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.0
Stable tag: 1.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enables WooCommerce users to register and log in using OTP (One-Time Password) verification via SMS, with a 60-second resend timer.

== Description ==

WooCommerce OTP Registration & Login is a plugin that enhances your WooCommerce store by allowing customers to register and log in using their phone numbers with OTP verification sent via SMS. It includes a customizable settings panel in WooCommerce, support for test mode, and a 60-second cooldown timer for resending OTPs.

Key features:
- OTP-based registration and login
- Configurable SMS API settings (username, password, API URL, sender ID)
- Customizable SMS messages for registration and login
- Test mode for development (logs OTP to console instead of sending SMS)
- 60-second resend timer with visual countdown
- Seamless integration with WooCommerce
- Shortcode support for easy placement

== Installation ==

1. **Upload the Plugin:**
   - Download the plugin zip file.
   - In your WordPress admin panel, go to Plugins > Add New > Upload Plugin.
   - Upload the zip file and click "Install Now".

2. **Activate the Plugin:**
   - After installation, click "Activate Plugin" or go to Plugins > Installed Plugins and activate "WooCommerce OTP Registration & Login".

3. **Ensure WooCommerce is Installed:**
   - This plugin requires WooCommerce to function. Install and activate WooCommerce if you haven't already.

4. **Configure Settings:**
   - Go to WooCommerce > Settings > OTP Settings in your WordPress admin panel.
   - Configure the following:
     - Enable/Disable OTP verification
     - Enable/Disable Test Mode
     - SMS API Username (e.g., your BulkSMS username)
     - SMS API Password (e.g., your BulkSMS password)
     - SMS API URL (default: https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30)
     - Sender ID (e.g., "AruToys")
     - Registration SMS Text (use {otp} as placeholder)
     - Login SMS Text (use {otp} as placeholder)
   - Save changes.

5. **Add Shortcodes:**
   - Use `[otp_registration_form]` on a page to display the registration form.
   - Use `[otp_login_form]` on a page to display the login form.
   - You can add these shortcodes via the WordPress editor or in your theme files.

== Usage ==

1. **Registration:**
   - Visitors enter their phone number in the registration form.
   - Click "Get OTP" to receive a 6-digit code via SMS (or console in test mode).
   - After receiving the OTP, enter it and click "Verify & Register".
   - The "Get OTP" button will show a 60-second countdown before allowing a resend.

2. **Login:**
   - Users can enter either their email or phone number.
   - If using a phone number, click "Get OTP" to receive a code.
   - Enter the OTP and click "Verify & Login".
   - The "Get OTP" button will show a 60-second countdown before allowing a resend.

3. **Test Mode:**
   - Enable test mode in settings to test without sending actual SMS.
   - OTPs will be logged to the browser console (open developer tools to see).

== Frequently Asked Questions ==

= What do I need to use this plugin? =
You need an active WooCommerce installation and an SMS API account (e.g., BulkSMS) to send OTPs. Configure your API credentials in the settings.

= How does the 60-second timer work? =
After requesting an OTP, the "Get OTP" button becomes "Resend OTP (60s)" and counts down. You can't request another OTP until the timer reaches zero.

= Can I customize the SMS messages? =
Yes, go to WooCommerce > Settings > OTP Settings and edit the Registration SMS Text and Login SMS Text fields. Use {otp} as a placeholder for the code.

= What happens if WooCommerce isn’t installed? =
The plugin will display an admin notice and won’t function until WooCommerce is activated.

== Screenshots ==

1. OTP Settings in WooCommerce admin panel.
2. Registration form with OTP input and 60-second timer.
3. Login form with phone number OTP option.

== Changelog ==

= 1.8 =
* Added 60-second resend OTP timer with visual countdown.
* Improved plugin structure with separate files for core, settings, and AJAX.

= 1.7 =
* Initial structured version with settings panel.

== Upgrade Notice ==

= 1.8 =
This update adds a 60-second resend timer. Update your shortcodes and test the new functionality.

== Additional Notes ==

- The plugin uses the BulkSMS API by default. Modify the API URL and credentials in settings if using a different provider.
- Ensure your server has cURL enabled for SMS API requests.
- For support, contact [Your Contact Info].
