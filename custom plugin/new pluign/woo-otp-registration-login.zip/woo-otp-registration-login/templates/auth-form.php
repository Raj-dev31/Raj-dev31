<?php if (!defined('ABSPATH')) exit; ?>
<form method="post" class="auth-form woocommerce-form" id="auth-form">
    <p class="form-row form-row-wide">
        <label for="auth_input"><?php _e('Phone Number or Email', 'woo-otp'); ?> <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input input-text" name="auth_input" id="auth_input" value="" required />
        <p id="auth-input-error" style="color: red; display: none;"></p>
    </p>

    <!-- Phone Section -->
    <div id="phone-section" style="display: none;">
        <p class="form-row">
            <button type="button" id="sendAuthOtp" class="button woocommerce-button"><?php _e('Get OTP', 'woo-otp'); ?></button>
        </p>
        <div id="otp-section" style="display:none;">
            <p class="form-row form-row-wide">
                <label for="auth_otp_code"><?php _e('Enter OTP', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="text" class="input-text" name="otp_code" id="auth_otp_code" maxlength="6" />
            </p>
            <p class="form-row">
                <button type="button" id="verifyAuthOtp" class="button woocommerce-button"><?php _e('Verify OTP', 'woo-otp'); ?></button>
            </p>
        </div>
        <div id="register-section" style="display:none;">
            <p id="register-message" style="color: green;"></p>
            <p class="form-row">
                <button type="button" id="registerBtn" class="button woocommerce-button"><?php _e('Register', 'woo-otp'); ?></button>
            </p>
            <div id="register-otp-section" style="display:none;">
                <p class="form-row form-row-wide">
                    <label for="reg_otp_code"><?php _e('Enter Registration OTP', 'woo-otp'); ?> <span class="required">*</span></label>
                    <input type="text" class="input-text" name="reg_otp_code" id="reg_otp_code" maxlength="6" />
                </p>
                <p class="form-row">
                    <button type="button" id="verifyRegOtp" class="button woocommerce-button"><?php _e('Verify & Register', 'woo-otp'); ?></button>
                </p>
            </div>
        </div>
    </div>

    <!-- Email Section -->
    <div id="email-section" style="display: none;">
        <div id="email-login-section">
            <p class="form-row form-row-wide password-wrapper">
                <label for="auth_password"><?php _e('Password', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="password" class="input-text" name="password" id="auth_password" required />
                <span class="toggle-password dashicons dashicons-visibility" data-target="auth_password"></span>
            </p>
            <p class="form-row">
                <button type="submit" class="button woocommerce-button" name="login" value="login"><?php _e('Login', 'woo-otp'); ?></button>
            </p>
        </div>
        <div id="email-register-section" style="display:none;">
            <p id="email-register-message" style="color: red;"></p>
            <p class="form-row form-row-wide">
                <label for="reg_phone"><?php _e('Phone Number', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="text" class="input-text" name="reg_phone" id="reg_phone" maxlength="13" placeholder="+91" />
            </p>
            <p class="form-row form-row-wide">
                <label for="reg_password"><?php _e('Password', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="password" class="input-text" name="reg_password" id="reg_password" />
                <span class="toggle-password dashicons dashicons-visibility" data-target="reg_password"></span>
            </p>
            <p class="form-row form-row-wide password-wrapper">
                <label for="reg_password_confirm"><?php _e('Repeat Password', 'woo-otp'); ?> <span class="required">*</span></label>
                <input type="password" class="input-text" name="reg_password_confirm" id="reg_password_confirm" />
                <span class="toggle-password dashicons dashicons-visibility" data-target="reg_password_confirm"></span>
            </p>
            <p class="form-row">
                <button type="submit" class="button woocommerce-button" name="register" value="register"><?php _e('Register', 'woo-otp'); ?></button>
            </p>
        </div>
    </div>

    <input type="hidden" name="woocommerce-auth-nonce" value="<?php echo wp_create_nonce('woocommerce-auth'); ?>">
    <p id="auth-message" style="color: red; display: none;"></p>
</form>