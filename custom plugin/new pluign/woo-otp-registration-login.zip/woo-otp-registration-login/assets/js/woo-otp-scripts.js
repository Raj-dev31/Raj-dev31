jQuery(document).ready(function($) {
    if (woo_ajax.otp_enabled !== 'yes') {
        $('.auth-form').hide();
        return;
    }

    console.log('Initial woo_ajax.nonce:', woo_ajax.nonce);

    function startCountdown(button, messageElement, duration = 60) {
        let timeLeft = duration;
        button.prop('disabled', true).text(`Resend OTP (${timeLeft}s)`);
        
        let timer = setInterval(function() {
            timeLeft--;
            button.text(`Resend OTP (${timeLeft}s)`);
            if (timeLeft <= 0) {
                clearInterval(timer);
                button.text('Get OTP').prop('disabled', false);
                $('#otp-section').hide();
                messageElement.hide();
            }
        }, 1000);
    }

    function showMessage(message, color) {
        $('#auth-message').text(message).css('color', color).show().prependTo('#auth-form');
    }

    $('#auth_input').on('input', function() {
        let val = $(this).val().trim();
        let isPhone = /^\+?\d+$/.test(val.replace(/\s/g, ''));
        let isEmail = val.includes('@') || val.includes('.com');

        if (isPhone) {
            if (val.length >= 3 && !val.startsWith('+91')) {
                $(this).val('+91' + val.replace('+91', ''));
            }
            $('#phone-section').show();
            $('#email-section, #otp-section, #register-section, #email-register-section, #register-otp-section').hide();
            $('#auth-input-error, #auth-message').hide();
        } else if (isEmail) {
            $('#email-section').show();
            $('#phone-section, #otp-section, #register-section, #register-otp-section, #email-register-section').hide();
            $('#email-login-section').show();
            $('#auth-input-error, #auth-message').hide();
        } else {
            $('#phone-section, #email-section, #otp-section, #register-section, #email-register-section, #register-otp-section').hide();
        }
    });

    $('#reg_phone').on('input', function() {
        let val = $(this).val().trim();
        if (val.length >= 3 && !val.startsWith('+91')) {
            $(this).val('+91' + val.replace('+91', ''));
        }
    });

    $('#auth-form').on('submit', function(e) {
        e.preventDefault();
        let isEmail = $('#auth_input').val().includes('@') || $('#auth_input').val().includes('.com');
        console.log('Form submitted - isEmail:', isEmail);

        if (isEmail && $(this).find('[name="login"]').is(':visible')) {
            let email = $('#auth_input').val();
            let password = $('#auth_password').val();
            console.log('Login attempt:', email);

            let loginData = {
                'auth_input': email,
                'password': password,
                'login': '1',
                'woocommerce-auth-nonce': woo_ajax.nonce
            };
            $.ajax({
                url: window.location.href,
                type: 'POST',
                data: loginData,
                beforeSend: function() {
                    console.log('Email login form data:', loginData);
                },
                success: function(response) {
                    console.log('Email login response:', response);
                    if (response.success) {
                        showMessage(response.data.message, 'green');
                        setTimeout(function() {
                            window.location.href = response.data.redirect || woo_ajax.myaccount_url;
                        }, 500);
                    } else {
                        if (response.data.message.includes('not registered')) {
                            showMessage('You are not registered with us. Please Register.', 'green');
                            $('#email-login-section').hide();
                            $('#email-register-section').show();
                        } else {
                            showMessage(response.data.message, 'red');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Email login AJAX error:', status, error, xhr.responseText);
                    showMessage('Something went wrong. Please try again.', 'red');
                }
            });
        } else if (isEmail && $(this).find('[name="register"]').is(':visible')) {
            let email = $('#auth_input').val();
            let phone = $('#reg_phone').val().replace('+91', '');
            let password = $('#reg_password').val();
            let passwordConfirm = $('#reg_password_confirm').val();
            console.log('Email registration attempt:', { email, phone, password });

            if (!phone) {
                showMessage('Please provide a phone number to continue.', 'red');
                return;
            }
            if (!password) {
                showMessage('Please enter a password.', 'red');
                return;
            }
            if (!passwordConfirm) {
                showMessage('Please confirm your password.', 'red');
                return;
            }
            if (password !== passwordConfirm) {
                showMessage('Passwords don’t match. Please check and try again.', 'red');
                return;
            }
            if (phone.length !== 10) {
                showMessage('Please enter a valid 10-digit phone number after +91.', 'red');
                return;
            }

            let formData = {
                'auth_input': email,
                'reg_phone': '+91' + phone,
                'reg_password': password,
                'reg_password_confirm': passwordConfirm,
                'register': '1',
                'woocommerce-auth-nonce': woo_ajax.nonce
            };
            $.ajax({
                url: window.location.href,
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    console.log('Email registration form data:', formData);
                },
                success: function(response) {
                    console.log('Email registration response:', response);
                    if (response.success) {
                        showMessage(response.data.message, 'green');
                        setTimeout(function() {
                            window.location.href = response.data.redirect || woo_ajax.myaccount_url;
                        }, 500);
                    } else {
                        showMessage(response.data.message, 'red');
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Email registration AJAX error:', status, error, xhr.responseText);
                    showMessage('Something went wrong. Please try again.', 'red');
                }
            });
        }
    });

    $('#sendAuthOtp').on('click', function() {
        let $this = $(this);
        let phone = $('#auth_input').val().replace('+91', '');
        let $message = $('#auth-message');

        if (phone.length !== 10) {
            showMessage('Please enter a valid 10-digit phone number.', 'red');
            return;
        }

        $this.text('Sending...').prop('disabled', true);
        let otpData = {
            action: 'send_otp',
            phone: phone,
            nonce: woo_ajax.nonce,
            context: 'auth'
        };
        $.post(woo_ajax.ajax_url, otpData, function(response) {
            console.log('Send OTP request data:', otpData);
            console.log('Send OTP response:', response);
            if (response.success) {
                showMessage(response.data.message, 'green');
                $('#otp-section').show();
                startCountdown($this, $message);
                if (woo_ajax.test_mode === 'yes') {
                    console.log('Test OTP:', response.data.otp);
                }
            } else {
                $this.text('Get OTP').prop('disabled', false);
                showMessage(response.data.message || 'Failed to send OTP. Please try again.', 'red');
            }
        }).fail(function(xhr, status, error) {
            console.log('Send OTP AJAX error:', status, error, xhr.responseText);
            $this.text('Get OTP').prop('disabled', false);
            showMessage('Error sending OTP. Please try again.', 'red');
        });
    });

    $('#verifyAuthOtp').on('click', function() {
        let $this = $(this);
        let phone = $('#auth_input').val().replace('+91', '');
        let otp = $('#auth_otp_code').val();
        let $message = $('#auth-message');

        if (otp.length !== 6) {
            showMessage('Please enter a valid 6-digit OTP.', 'red');
            return;
        }

        $this.text('Verifying...').prop('disabled', true);
        let verifyData = {
            action: 'verify_otp',
            phone: phone,
            otp: otp,
            nonce: woo_ajax.nonce,
            context: 'auth'
        };
        $.post(woo_ajax.ajax_url, verifyData, function(response) {
            console.log('Verify OTP request data:', verifyData);
            console.log('Verify OTP response:', response);
            $this.text('Verify OTP').prop('disabled', false);
            if (response.success) {
                showMessage(response.data.message, 'green');
                let loginData = {
                    'auth_input': '+91' + phone,
                    'otp_verified': '1',
                    'woocommerce-auth-nonce': woo_ajax.nonce
                };
                $.ajax({
                    url: window.location.href,
                    type: 'POST',
                    data: loginData,
                    beforeSend: function() {
                        console.log('Phone login form data:', loginData);
                    },
                    success: function(response) {
                        console.log('Phone login response:', response);
                        if (response.success) {
                            showMessage(response.data.message, 'green');
                            setTimeout(function() {
                                window.location.href = response.data.redirect || woo_ajax.myaccount_url;
                            }, 500);
                        } else {
                            if (response.data.message.includes('not registered')) {
                                showMessage('You are not registered with us. Please Register.', 'green');
                                $('#sendAuthOtp').hide();
                                $('#otp-section').hide();
                                $this.hide();
                                $('#register-section').show();
                            } else {
                                showMessage(response.data.message, 'red');
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log('Phone login AJAX error:', status, error, xhr.responseText);
                        showMessage('Login failed. Please try again.', 'red');
                    }
                });
            } else {
                showMessage(response.data.message || 'OTP verification failed. Please try again.', 'red');
            }
        }).fail(function(xhr, status, error) {
            console.log('Verify OTP AJAX error:', status, error, xhr.responseText);
            $this.text('Verify OTP').prop('disabled', false);
            showMessage('Error verifying OTP. Please try again.', 'red');
        });
    });

    $('#registerBtn').on('click', function() {
        let $this = $(this);
        let phone = $('#auth_input').val().replace('+91', '');
        let $message = $('#auth-message');

        if (phone.length !== 10) {
            showMessage('Please enter a valid 10-digit phone number.', 'red');
            return;
        }

        $this.text('Sending Registration OTP...').prop('disabled', true);
        let regOtpData = {
            action: 'send_otp',
            phone: phone,
            nonce: woo_ajax.nonce,
            context: 'register'
        };
        $.post(woo_ajax.ajax_url, regOtpData, function(response) {
            console.log('Send Registration OTP request data:', regOtpData);
            console.log('Send Registration OTP response:', response);
            if (response.success) {
                showMessage(response.data.message, 'green');
                $('#register-otp-section').show();
                $('#registerBtn').hide();
                startCountdown($this, $message);
                if (woo_ajax.test_mode === 'yes') {
                    console.log('Test Registration OTP:', response.data.otp);
                }
            } else {
                $this.text('Register').prop('disabled', false);
                showMessage(response.data.message || 'Failed to send OTP. Please try again.', 'red');
            }
        }).fail(function(xhr, status, error) {
            console.log('Send Registration OTP AJAX error:', status, error, xhr.responseText);
            $this.text('Register').prop('disabled', false);
            showMessage('Error sending OTP. Please try again.', 'red');
        });
    });

    $('#verifyRegOtp').on('click', function() {
        let $this = $(this);
        let phone = $('#auth_input').val().replace('+91', '');
        let otp = $('#reg_otp_code').val();
        let $message = $('#auth-message');

        if (otp.length !== 6) {
            showMessage('Please enter a valid 6-digit OTP.', 'red');
            return;
        }

        $this.text('Verifying...').prop('disabled', true);
        let verifyRegData = {
            action: 'verify_otp',
            phone: phone,
            otp: otp,
            nonce: woo_ajax.nonce,
            context: 'register'
        };
        $.post(woo_ajax.ajax_url, verifyRegData, function(response) {
            console.log('Verify Registration OTP request data:', verifyRegData);
            console.log('Verify Registration OTP response:', response);
            $this.text('Verify & Register').prop('disabled', false);
            if (response.success) {
                let regData = {
                    'auth_input': '+91' + phone,
                    'register': '1',
                    'reg_otp_verified': '1',
                    'woocommerce-auth-nonce': woo_ajax.nonce
                };
                $.ajax({
                    url: window.location.href,
                    type: 'POST',
                    data: regData,
                    beforeSend: function() {
                        console.log('Phone registration form data:', regData);
                    },
                    success: function(response) {
                        console.log('Phone registration response:', response);
                        if (response.success) {
                            showMessage(response.data.message, 'green');
                            setTimeout(function() {
                                showMessage(response.data.message, 'green');
                            }, 1000);
                            setTimeout(function() {
                                window.location.href = response.data.redirect || woo_ajax.myaccount_url;
                            }, 2000);
                        } else {
                            showMessage(response.data.message, 'red');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log('Phone registration AJAX error:', status, error, xhr.responseText);
                        showMessage('Registration failed. Please try again.', 'red');
                    }
                });
            } else {
                showMessage(response.data.message || 'OTP verification failed. Please try again.', 'red');
            }
        }).fail(function(xhr, status, error) {
            console.log('Verify Registration OTP AJAX error:', status, error, xhr.responseText);
            $this.text('Verify & Register').prop('disabled', false);
            showMessage('Error verifying OTP. Please try again.', 'red');
        });
    });

    // Toggle password visibility
    $('.toggle-password').on('click', function() {
        var targetId = $(this).data('target');
        var $input = $('#' + targetId);
        var isPassword = $input.attr('type') === 'password';
        
        if (isPassword) {
            $input.attr('type', 'text');
            $(this).removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            $input.attr('type', 'password');
            $(this).removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    });
});