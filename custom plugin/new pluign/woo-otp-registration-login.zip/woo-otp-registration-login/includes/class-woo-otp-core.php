<?php
if (!defined('ABSPATH')) {
    exit;
}

class Woo_OTP_Core {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->register_hooks();
    }

    private function register_hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_shortcode('otp_auth_form', [$this, 'auth_form']);
        add_action('init', [$this, 'handle_auth'], 20);
        add_action('wp_ajax_check_email_registration', [$this, 'check_email_registration']);
        add_action('wp_ajax_nopriv_check_email_registration', [$this, 'check_email_registration']);
        add_action('wp_ajax_check_phone_registration', [$this, 'check_phone_registration']);
        add_action('wp_ajax_nopriv_check_phone_registration', [$this, 'check_phone_registration']);
        add_action('wp_ajax_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_nopriv_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_verify_otp', [$this, 'verify_otp']);
        add_action('wp_ajax_nopriv_verify_otp', [$this, 'verify_otp']);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('woo-otp-styles', WOO_OTP_URL . 'assets/css/woo-otp-styles.css', array('dashicons'), WOO_OTP_VERSION);
        wp_enqueue_script('woo-otp-scripts', WOO_OTP_URL . 'assets/js/woo-otp-scripts.js', array('jquery'), WOO_OTP_VERSION, true);
        wp_localize_script('woo-otp-scripts', 'woo_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woocommerce-auth'),
            'test_mode' => get_option('woo_otp_test_mode', 'no'),
            'otp_enabled' => get_option('woo_otp_enable', 'yes'),
            'myaccount_url' => wc_get_page_permalink('myaccount')
        ));
    }

    public function auth_form() {
        if (is_user_logged_in()) {
            return '<p>' . __('You are already logged in.', 'woo-otp') . '</p>';
        }
        ob_start();
        include WOO_OTP_PATH . 'templates/auth-form.php';
        return ob_get_clean();
    }

    public function handle_auth() {
        error_log('Woo OTP: handle_auth started');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            error_log('Woo OTP: Not a POST request');
            return;
        }

        if (isset($_POST['action']) && in_array($_POST['action'], ['send_otp', 'verify_otp', 'check_email_registration', 'check_phone_registration'])) {
            error_log('Woo OTP: Skipping handle_auth for AJAX action: ' . $_POST['action']);
            return;
        }

        if (!isset($_POST['woocommerce-auth-nonce']) || empty($_POST['woocommerce-auth-nonce'])) {
            error_log('Woo OTP: Nonce not set or empty');
            error_log('Woo OTP: Full POST data on nonce failure: ' . print_r($_POST, true));
            wp_send_json(['success' => false, 'data' => ['message' => __('Oops! Something went wrong with the security check. Please try again.', 'woo-otp')]]);
            return;
        }

        if (!wp_verify_nonce($_POST['woocommerce-auth-nonce'], 'woocommerce-auth')) {
            error_log('Woo OTP: Nonce verification failed - Received: ' . $_POST['woocommerce-auth-nonce']);
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh the page and try again.', 'woo-otp')]]);
            return;
        }

        error_log('Woo OTP: Nonce verified successfully');
        error_log('Woo OTP: POST data: ' . print_r($_POST, true));

        $input = sanitize_text_field($_POST['auth_input']);
        $is_email = is_email($input);

        // Handle Email Login
        if (isset($_POST['login']) && $is_email) {
            error_log('Woo OTP: Processing email login for ' . $input);
            if (empty($_POST['password'])) {
                error_log('Woo OTP: Password empty for login');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please enter your password to log in.', 'woo-otp')]]);
                return;
            }
            
            $user = get_user_by('email', $input) ?: get_user_by('login', $input);
            if (!$user) {
                error_log('Woo OTP: User not found for ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('You are not registered with us. Please Register.', 'woo-otp')]]);
                return;
            }

            $auth = wp_authenticate_email_password(null, $input, $_POST['password']);
            if (is_wp_error($auth)) {
                error_log('Woo OTP: Authentication failed for ' . $input . ' - Error: ' . $auth->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Incorrect password. Please try again or reset it.', 'woo-otp')]]);
                return;
            }
                
            wp_set_current_user($auth->ID);
            wp_set_auth_cookie($auth->ID);
            error_log('Woo OTP: Login successful for ' . $input . ', redirecting to My Account');
            wp_send_json(['success' => true, 'data' => ['message' => __('Welcome back! You’re logged in successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
            exit();
        }

        // Handle Email Registration with Phone Number
        if (isset($_POST['register']) && $is_email) {
            error_log('Woo OTP: Processing email registration for ' . $input);

            $existing_user = get_user_by('email', $input) ?: get_user_by('login', $input);
            if ($existing_user) {
                error_log('Woo OTP: Email already registered: ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('This email is already registered. Try logging in instead.', 'woo-otp')]]);
                return;
            }

            $phone = sanitize_text_field($_POST['reg_phone']);
            $phone = str_replace('+91', '', $phone);
            $phone_users = get_users(['meta_key' => 'billing_phone', 'meta_value' => $phone]);
            $phone_username = get_user_by('login', $phone);
            if (!empty($phone_users) || $phone_username) {
                error_log('Woo OTP: Phone number already registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('This phone number is already linked to another account.', 'woo-otp')]]);
                return;
            }

            if (empty($_POST['reg_phone'])) {
                error_log('Woo OTP: Phone empty for registration');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please provide a phone number to continue.', 'woo-otp')]]);
                return;
            }

            if (empty($_POST['reg_password']) || empty($_POST['reg_password_confirm'])) {
                error_log('Woo OTP: Password fields empty for registration');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please fill in both password fields.', 'woo-otp')]]);
                return;
            }

            if ($_POST['reg_password'] !== $_POST['reg_password_confirm']) {
                error_log('Woo OTP: Passwords do not match for ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('Passwords don’t match. Please check and try again.', 'woo-otp')]]);
                return;
            }

            $userdata = [
                'user_login' => $input,
                'user_email' => $input,
                'user_pass' => $_POST['reg_password'],
                'role' => 'customer'
            ];
            $user_id = wp_insert_user($userdata);
            if (!is_wp_error($user_id)) {
                update_user_meta($user_id, 'billing_phone', $phone);
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Registration successful for ' . $input . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Great! Your account is created successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Registration failed for ' . $input . ' - Error: ' . $user_id->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Something went wrong during registration. Please try again.', 'woo-otp')]]);
                return;
            }
        }

        // Handle Phone OTP Login
        if (isset($_POST['otp_verified']) && !$is_email) {
            error_log('Woo OTP: Processing phone OTP login for ' . $input);
            $phone = str_replace('+91', '', $input);
            $users = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);
            if (!empty($users)) {
                $user_id = $users[0]->ID;
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Phone login successful for ' . $phone . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Welcome back! You’re logged in successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Phone not registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('Looks like you’re not registered yet. Let’s get you signed up!', 'woo-otp')]]);
                return;
            }
        }

        // Handle Phone Registration
        if (isset($_POST['register']) && !$is_email && isset($_POST['reg_otp_verified'])) {
            error_log('Woo OTP: Processing phone registration for ' . $input);
            $phone = str_replace('+91', '', $input);
            $phone_users = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);
            if (!empty($phone_users)) {
                error_log('Woo OTP: Phone number already registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('This phone number is already registered. Try logging in.', 'woo-otp')]]);
                return;
            }

            $userdata = [
                'user_login' => $phone,
                'user_pass' => wp_generate_password(),
                'role' => 'customer'
            ];
            $user_id = wp_insert_user($userdata);
            if (!is_wp_error($user_id)) {
                update_user_meta($user_id, 'billing_phone', $phone);
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Phone registration successful for ' . $phone . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Awesome! Your account is created successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Phone registration failed for ' . $phone . ' - Error: ' . $user_id->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Oops! Registration failed. Please try again.', 'woo-otp')]]);
                return;
            }
        }

        error_log('Woo OTP: No matching action found for input: ' . $input);
        wp_send_json(['success' => false, 'data' => ['message' => __('Something went wrong. Please try again.', 'woo-otp')]]);
    }

    public function check_email_registration() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: check_email_registration nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $email = sanitize_email($_POST['email'] ?? '');
        error_log('Woo OTP: check_email_registration called with email: ' . $email);

        if (empty($email)) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter an email address.', 'woo-otp')]]);
            return;
        }

        $user = get_user_by('email', $email) ?: get_user_by('login', $email);
        wp_send_json(['success' => true, 'data' => ['is_registered' => !!$user]]);
    }

    public function check_phone_registration() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: check_phone_registration nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        error_log('Woo OTP: check_phone_registration called with phone: ' . $phone);

        if (empty($phone)) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a phone number.', 'woo-otp')]]);
            return;
        }

        $users = get_users(['meta_key' => 'billing_phone', 'meta_value' => $phone]);
        $phone_username = get_user_by('login', $phone);
        wp_send_json(['success' => true, 'data' => ['is_registered' => !empty($users) || !!$phone_username]]);
    }

    public function send_otp() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: send_otp nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $context = sanitize_text_field($_POST['context'] ?? 'auth');
        error_log('Woo OTP: send_otp called with phone: ' . $phone . ', context: ' . $context);

        if (empty($phone) || strlen($phone) !== 10) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a valid 10-digit phone number.', 'woo-otp')]]);
            return;
        }

        $otp = rand(100000, 999999);
        set_transient('woo_otp_' . $phone . '_' . $context, $otp, 5 * MINUTE_IN_SECONDS);

        wp_send_json([
            'success' => true,
            'data' => [
                'otp' => get_option('woo_otp_test_mode', 'no') === 'yes' ? $otp : null,
                'message' => __('OTP sent successfully! Check your phone.', 'woo-otp')
            ]
        ]);
    }

    public function verify_otp() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: verify_otp nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $otp = sanitize_text_field($_POST['otp'] ?? '');
        $context = sanitize_text_field($_POST['context'] ?? 'auth');
        error_log('Woo OTP: verify_otp called with phone: ' . $phone . ', otp: ' . $otp . ', context: ' . $context);

        if (empty($phone) || empty($otp) || strlen($otp) !== 6) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a valid 6-digit OTP.', 'woo-otp')]]);
            return;
        }

        $stored_otp = get_transient('woo_otp_' . $phone . '_' . $context);
        if ($stored_otp && $stored_otp == $otp) {
            delete_transient('woo_otp_' . $phone . '_' . $context);
            wp_send_json(['success' => true, 'data' => ['message' => __('OTP verified! You’re good to go.', 'woo-otp')]]);
        } else {
            wp_send_json(['success' => false, 'data' => ['message' => __('Invalid OTP. Please try again.', 'woo-otp')]]);
        }
    }
}