<?php
if (!defined('ABSPATH')) {
    exit;
}

class Woo_OTP_Core {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->register_hooks();
    }

    private function register_hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_shortcode('otp_auth_form', [$this, 'auth_form']);
        add_action('init', [$this, 'handle_auth'], 20);
        add_action('wp_ajax_check_email_registration', [$this, 'check_email_registration']);
        add_action('wp_ajax_nopriv_check_email_registration', [$this, 'check_email_registration']);
        add_action('wp_ajax_check_phone_registration', [$this, 'check_phone_registration']);
        add_action('wp_ajax_nopriv_check_phone_registration', [$this, 'check_phone_registration']);
        add_action('wp_ajax_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_nopriv_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_verify_otp', [$this, 'verify_otp']);
        add_action('wp_ajax_nopriv_verify_otp', [$this, 'verify_otp']);
        add_action('woocommerce_save_account_details', [$this, 'custom_save_account_details'], 5, 1);
        add_filter('woocommerce_save_account_details_required_fields', [$this, 'make_fields_optional'], 999);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_custom_styles'], 20);
        add_filter('woocommerce_locate_template', [$this, 'override_edit_account_template'], 10, 3);
    }

    public function enqueue_scripts() {
        wp_enqueue_style('woo-otp-styles', WOO_OTP_URL . 'assets/css/woo-otp-styles.css', array('dashicons'), WOO_OTP_VERSION);
        wp_enqueue_script('woo-otp-scripts', WOO_OTP_URL . 'assets/js/woo-otp-scripts.js', array('jquery'), WOO_OTP_VERSION, true);
        wp_localize_script('woo-otp-scripts', 'woo_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('woocommerce-auth'),
            'test_mode' => get_option('woo_otp_test_mode', 'no'),
            'otp_enabled' => get_option('woo_otp_enable', 'yes'),
            'myaccount_url' => wc_get_page_permalink('myaccount')
        ));
    }

    public function enqueue_custom_styles() {
        if (is_account_page() && is_wc_endpoint_url('edit-account')) {
            $user = wp_get_current_user();
            $display_name = $user->display_name;
            $is_phone = preg_match('/^\+?\d{10,}$/', $display_name);

            $custom_css = "
                #account_display_name, #account_email {
                    background-color: #f0f0f0;
                    cursor: not-allowed;
                }
            ";
            wp_add_inline_style('woo-otp-styles', $custom_css);
        }
    }

    public function auth_form() {
        if (is_user_logged_in()) {
            return '<p>' . __('You are already logged in.', 'woo-otp') . '</p>';
        }
        ob_start();
        include WOO_OTP_PATH . 'templates/auth-form.php';
        return ob_get_clean();
    }

    public function override_edit_account_template($template, $template_name, $template_path) {
        if ($template_name === 'myaccount/form-edit-account.php') {
            ob_start();
            $this->render_custom_edit_account_form();
            $custom_template = ob_get_clean();
            $temp_file = WOO_OTP_PATH . 'templates/form-edit-account.php';
            file_put_contents($temp_file, $custom_template);
            return $temp_file;
        }
        return $template;
    }

    public function render_custom_edit_account_form() {
        ?>
        <?php defined('ABSPATH') || exit; ?>
        <?php do_action('woocommerce_before_edit_account_form'); ?>
        <form class="woocommerce-EditAccountForm edit-account" action="" method="post" <?php do_action('woocommerce_edit_account_form_tag'); ?> >
            <?php do_action('woocommerce_edit_account_form_start'); ?>
            <?php
            $user = wp_get_current_user();
            $display_name = $user->display_name;
            $is_phone = preg_match('/^\+?\d{10,}$/', $display_name);
            $is_email = is_email($display_name);
            ?>
            <p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
                <label for="account_first_name"><?php esc_html_e('First name', 'woocommerce'); ?></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_first_name" id="account_first_name" autocomplete="given-name" value="<?php echo esc_attr($user->first_name); ?>" />
            </p>
            <p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
                <label for="account_last_name"><?php esc_html_e('Last name', 'woocommerce'); ?></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_last_name" id="account_last_name" autocomplete="family-name" value="<?php echo esc_attr($user->last_name); ?>" />
            </p>
            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="account_display_name"><?php esc_html_e('Display name', 'woocommerce'); ?> <span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_display_name" id="account_display_name" value="<?php echo esc_attr($display_name); ?>" readonly="readonly" />
                <span><em><?php esc_html_e('This will be how your name will be displayed in the account section and in reviews. It cannot be changed here.', 'woocommerce'); ?></em></span>
            </p>
            <?php if (!$is_phone) : ?>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="account_email"><?php esc_html_e('Email address', 'woocommerce'); ?> <span class="required">*</span></label>
                    <input type="email" class="woocommerce-Input woocommerce-Input--email input-text" name="account_email" id="account_email" autocomplete="email" value="<?php echo esc_attr($user->user_email); ?>" readonly="readonly" />
                </p>
            <?php endif; ?>
            <?php if (!$is_phone) : ?>
                <fieldset class="password-fieldset">
                    <legend><?php esc_html_e('Password Change', 'woocommerce'); ?></legend>
                    <!-- Hidden current password field to satisfy WooCommerce -->
                    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                        <label for="password_current"><?php esc_html_e('Current password', 'woocommerce'); ?></label>
                        <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password_current" id="password_current" autocomplete="off" value="" />
                    </p>
                    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                        <label for="password_1"><?php esc_html_e('New password (leave blank to leave unchanged)', 'woocommerce'); ?></label>
                        <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password_1" id="password_1" autocomplete="off" />
                    </p>
                    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                        <label for="password_2"><?php esc_html_e('Confirm new password', 'woocommerce'); ?></label>
                        <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password_2" id="password_2" autocomplete="off" />
                    </p>
                </fieldset>
            <?php endif; ?>
            <?php do_action('woocommerce_edit_account_form'); ?>
            <p>
                <?php wp_nonce_field('save_account_details', 'save-account-details-nonce'); ?>
                <button type="submit" class="woocommerce-Button button<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>" name="save_account_details" value="<?php esc_attr_e('Save changes', 'woocommerce'); ?>"><?php esc_html_e('Save changes', 'woocommerce'); ?></button>
                <input type="hidden" name="action" value="save_account_details" />
            </p>
            <?php do_action('woocommerce_edit_account_form_end'); ?>
        </form>
        <?php do_action('woocommerce_after_edit_account_form'); ?>
        <?php
    }

    public function make_fields_optional($required_fields) {
        // Remove first_name, last_name, and password_current from required fields
        unset($required_fields['account_first_name']);
        unset($required_fields['account_last_name']);
        return $required_fields;
    }

    public function custom_save_account_details($user_id) {
        if (!isset($_POST['save-account-details-nonce']) || !wp_verify_nonce($_POST['save-account-details-nonce'], 'save_account_details')) {
            wc_add_notice(__('Security check failed. Please try again.', 'woo-otp'), 'error');
            return;
        }

        $user = wp_get_current_user();
        $display_name = $user->display_name;
        $is_phone = preg_match('/^\+?\d{10,}$/', $display_name);
        $is_email = is_email($display_name);

        // Prevent changing display name and email
        $original_display_name = $user->display_name;
        $original_email = $user->user_email;

        // Update optional fields
        $first_name = isset($_POST['account_first_name']) ? sanitize_text_field($_POST['account_first_name']) : '';
        $last_name = isset($_POST['account_last_name']) ? sanitize_text_field($_POST['account_last_name']) : '';

        // Update password if provided (for email users only)
        if (!$is_phone && !empty($_POST['password_1']) && !empty($_POST['password_2'])) {
            if ($_POST['password_1'] === $_POST['password_2']) {
                wp_set_password($_POST['password_1'], $user_id);
                wc_add_notice(__('Password updated successfully.', 'woo-otp'), 'success');
            } else {
                wc_add_notice(__('Passwords do not match.', 'woo-otp'), 'error');
                return;
            }
        } elseif (!$is_phone && !empty($_POST['password_1']) && empty($_POST['password_2'])) {
            wc_add_notice(__('Please confirm your new password.', 'woo-otp'), 'error');
            return;
        }

        // Save user data
        $userdata = array(
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => $original_display_name, // Keep original
            'user_email' => $original_email,          // Keep original
        );
        $result = wp_update_user($userdata);

        if (is_wp_error($result)) {
            wc_add_notice(__('Error saving account details. Please try again.', 'woo-otp'), 'error');
        } else {
            wc_add_notice(__('Account details updated successfully.', 'woo-otp'), 'success');
        }
    }

    public function handle_auth() {
        error_log('Woo OTP: handle_auth started');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['auth_input'])) {
            error_log('Woo OTP: Skipping handle_auth - not a custom form POST request');
            return;
        }

        if (isset($_POST['action']) && in_array($_POST['action'], ['send_otp', 'verify_otp', 'check_email_registration', 'check_phone_registration'])) {
            error_log('Woo OTP: Skipping handle_auth for AJAX action: ' . $_POST['action']);
            return;
        }

        if (!isset($_POST['woocommerce-auth-nonce']) || empty($_POST['woocommerce-auth-nonce'])) {
            error_log('Woo OTP: Nonce not set or empty');
            error_log('Woo OTP: Full POST data on nonce failure: ' . print_r($_POST, true));
            wp_send_json(['success' => false, 'data' => ['message' => __('Oops! Something went wrong with the security check. Please try again.', 'woo-otp')]]);
            return;
        }

        if (!wp_verify_nonce($_POST['woocommerce-auth-nonce'], 'woocommerce-auth')) {
            error_log('Woo OTP: Nonce verification failed - Received: ' . $_POST['woocommerce-auth-nonce']);
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh the page and try again.', 'woo-otp')]]);
            return;
        }

        error_log('Woo OTP: Nonce verified successfully');
        error_log('Woo OTP: POST data: ' . print_r($_POST, true));

        $input = sanitize_text_field($_POST['auth_input']);
        $is_email = is_email($input);

        if (isset($_POST['login']) && $is_email) {
            error_log('Woo OTP: Processing email login for ' . $input);
            if (empty($_POST['password'])) {
                error_log('Woo OTP: Password empty for login');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please enter your password to log in.', 'woo-otp')]]);
                return;
            }
            
            $user = get_user_by('email', $input) ?: get_user_by('login', $input);
            if (!$user) {
                error_log('Woo OTP: User not found for ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('You are not registered with us. Please Register.', 'woo-otp')]]);
                return;
            }

            $auth = wp_authenticate_email_password(null, $input, $_POST['password']);
            if (is_wp_error($auth)) {
                error_log('Woo OTP: Authentication failed for ' . $input . ' - Error: ' . $auth->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Incorrect password. Please try again or reset it.', 'woo-otp')]]);
                return;
            }
                
            wp_set_current_user($auth->ID);
            wp_set_auth_cookie($auth->ID);
            error_log('Woo OTP: Login successful for ' . $input . ', redirecting to My Account');
            wp_send_json(['success' => true, 'data' => ['message' => __('Welcome back! You’re logged in successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
            exit();
        }

        if (isset($_POST['register']) && $is_email) {
            error_log('Woo OTP: Processing email registration for ' . $input);

            $existing_user = get_user_by('email', $input) ?: get_user_by('login', $input);
            if ($existing_user) {
                error_log('Woo OTP: Email already registered: ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('This email is already registered. Try logging in instead.', 'woo-otp')]]);
                return;
            }

            $phone = sanitize_text_field($_POST['reg_phone']);
            $phone = str_replace('+91', '', $phone);
            $phone_users = get_users(['meta_key' => 'billing_phone', 'meta_value' => $phone]);
            $phone_username = get_user_by('login', $phone);
            if (!empty($phone_users) || $phone_username) {
                error_log('Woo OTP: Phone number already registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('This phone number is already linked to another account.', 'woo-otp')]]);
                return;
            }

            if (empty($_POST['reg_phone'])) {
                error_log('Woo OTP: Phone empty for registration');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please provide a phone number to continue.', 'woo-otp')]]);
                return;
            }

            if (empty($_POST['reg_password']) || empty($_POST['reg_password_confirm'])) {
                error_log('Woo OTP: Password fields empty for registration');
                wp_send_json(['success' => false, 'data' => ['message' => __('Please fill in both password fields.', 'woo-otp')]]);
                return;
            }

            if ($_POST['reg_password'] !== $_POST['reg_password_confirm']) {
                error_log('Woo OTP: Passwords do not match for ' . $input);
                wp_send_json(['success' => false, 'data' => ['message' => __('Passwords don’t match. Please check and try again.', 'woo-otp')]]);
                return;
            }

            $userdata = [
                'user_login' => $input,
                'user_email' => $input,
                'user_pass' => $_POST['reg_password'],
                'role' => 'customer'
            ];
            $user_id = wp_insert_user($userdata);
            if (!is_wp_error($user_id)) {
                update_user_meta($user_id, 'billing_phone', $phone);
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Registration successful for ' . $input . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Great! Your account is created successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Registration failed for ' . $input . ' - Error: ' . $user_id->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Something went wrong during registration. Please try again.', 'woo-otp')]]);
                return;
            }
        }

        if (isset($_POST['otp_verified']) && !$is_email) {
            error_log('Woo OTP: Processing phone OTP login for ' . $input);
            $phone = str_replace('+91', '', $input);
            $users = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);
            if (!empty($users)) {
                $user_id = $users[0]->ID;
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Phone login successful for ' . $phone . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Welcome back! You’re logged in successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Phone not registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('Looks like you’re not registered yet. Let’s get you signed up!', 'woo-otp')]]);
                return;
            }
        }

        if (isset($_POST['register']) && !$is_email && isset($_POST['reg_otp_verified'])) {
            error_log('Woo OTP: Processing phone registration for ' . $input);
            $phone = str_replace('+91', '', $input);
            $phone_users = get_users([
                'meta_key' => 'billing_phone',
                'meta_value' => $phone,
                'number' => 1
            ]);
            if (!empty($phone_users)) {
                error_log('Woo OTP: Phone number already registered: ' . $phone);
                wp_send_json(['success' => false, 'data' => ['message' => __('This phone number is already registered. Try logging in.', 'woo-otp')]]);
                return;
            }

            $userdata = [
                'user_login' => $phone,
                'user_pass' => wp_generate_password(),
                'role' => 'customer'
            ];
            $user_id = wp_insert_user($userdata);
            if (!is_wp_error($user_id)) {
                update_user_meta($user_id, 'billing_phone', $phone);
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                error_log('Woo OTP: Phone registration successful for ' . $phone . ', redirecting to My Account');
                wp_send_json(['success' => true, 'data' => ['message' => __('Awesome! Your account is created successfully.', 'woo-otp'), 'redirect' => wc_get_page_permalink('myaccount')]]);
                exit();
            } else {
                error_log('Woo OTP: Phone registration failed for ' . $phone . ' - Error: ' . $user_id->get_error_message());
                wp_send_json(['success' => false, 'data' => ['message' => __('Oops! Registration failed. Please try again.', 'woo-otp')]]);
                return;
            }
        }

        error_log('Woo OTP: No matching action found for input: ' . $input);
        wp_send_json(['success' => false, 'data' => ['message' => __('Something went wrong. Please try again.', 'woo-otp')]]);
    }

    public function check_email_registration() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: check_email_registration nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $email = sanitize_email($_POST['email'] ?? '');
        error_log('Woo OTP: check_email_registration called with email: ' . $email);

        if (empty($email)) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter an email address.', 'woo-otp')]]);
            return;
        }

        $user = get_user_by('email', $email) ?: get_user_by('login', $email);
        wp_send_json(['success' => true, 'data' => ['is_registered' => !!$user]]);
    }

    public function check_phone_registration() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: check_phone_registration nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        error_log('Woo OTP: check_phone_registration called with phone: ' . $phone);

        if (empty($phone)) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a phone number.', 'woo-otp')]]);
            return;
        }

        $users = get_users(['meta_key' => 'billing_phone', 'meta_value' => $phone]);
        $phone_username = get_user_by('login', $phone);
        wp_send_json(['success' => true, 'data' => ['is_registered' => !empty($users) || !!$phone_username]]);
    }

    public function send_otp() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: send_otp nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $context = sanitize_text_field($_POST['context'] ?? 'auth');
        error_log('Woo OTP: send_otp called with phone: ' . $phone . ', context: ' . $context);

        if (empty($phone) || strlen($phone) !== 10) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a valid 10-digit phone number.', 'woo-otp')]]);
            return;
        }

        $otp = rand(100000, 999999);
        set_transient('woo_otp_' . $phone . '_' . $context, $otp, 5 * MINUTE_IN_SECONDS);

        wp_send_json([
            'success' => true,
            'data' => [
                'otp' => get_option('woo_otp_test_mode', 'no') === 'yes' ? $otp : null,
                'message' => __('OTP sent successfully! Check your phone.', 'woo-otp')
            ]
        ]);
    }

    public function verify_otp() {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'woocommerce-auth')) {
            error_log('Woo OTP: verify_otp nonce verification failed');
            wp_send_json(['success' => false, 'data' => ['message' => __('Security check failed. Please refresh and try again.', 'woo-otp')]]);
            return;
        }

        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $otp = sanitize_text_field($_POST['otp'] ?? '');
        $context = sanitize_text_field($_POST['context'] ?? 'auth');
        error_log('Woo OTP: verify_otp called with phone: ' . $phone . ', otp: ' . $otp . ', context: ' . $context);

        if (empty($phone) || empty($otp) || strlen($otp) !== 6) {
            wp_send_json(['success' => false, 'data' => ['message' => __('Please enter a valid 6-digit OTP.', 'woo-otp')]]);
            return;
        }

        $stored_otp = get_transient('woo_otp_' . $phone . '_' . $context);
        if ($stored_otp && $stored_otp == $otp) {
            delete_transient('woo_otp_' . $phone . '_' . $context);
            wp_send_json(['success' => true, 'data' => ['message' => __('OTP verified! You’re good to go.', 'woo-otp')]]);
        } else {
            wp_send_json(['success' => false, 'data' => ['message' => __('Invalid OTP. Please try again.', 'woo-otp')]]);
        }
    }
}